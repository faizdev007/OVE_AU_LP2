<?php

namespace App\Livewire\SiliconValley;

use Livewire\Component;

class TechTeam extends Component
{
    public function render()
    {
        return view('livewire.silicon-valley.tech-team');
    }
}
