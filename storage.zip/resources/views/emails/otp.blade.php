<center>
    <h2>Your OTP Code</h2>
    <h1><strong>{{ $otp }}</strong></h1>
</center>