<div class="flex aspect-square size-10 items-center justify-center rounded-md bg-gray-100 text-accent-foreground">
    <x-app-logo-icon class="size-5 aspect-[1/1] fill-current text-white dark:text-black" />
</div>
<div class="ms-1 grid flex-1 text-start text-sm">
    <span class="mb-0.5 leading-none font-semibold">OVE Landing Pages</span>
</div>
