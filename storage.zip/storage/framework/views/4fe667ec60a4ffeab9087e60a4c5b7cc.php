<?php if (isset($component)) { $__componentOriginalad01e5326b1985fd7ab2567e3051ba22 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad01e5326b1985fd7ab2567e3051ba22 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.page.siliconvalley','data' => ['header' => $header,'seo' => $seo??['metaTitle'=>'','metaDescription'=>''],'title' => __('Optimal Virtual Employee')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.page.siliconvalley'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($header),'seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo??['metaTitle'=>'','metaDescription'=>'']),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Optimal Virtual Employee'))]); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.hero-section', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.text-slider', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.dev-profile', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.az-block', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.ai-block', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.query-block', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.hiring-process', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.tech-team', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.start-scaling-your-team', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.ctn', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-9', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('silicon-valley.our-offices', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2586627344-10', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad01e5326b1985fd7ab2567e3051ba22)): ?>
<?php $attributes = $__attributesOriginalad01e5326b1985fd7ab2567e3051ba22; ?>
<?php unset($__attributesOriginalad01e5326b1985fd7ab2567e3051ba22); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad01e5326b1985fd7ab2567e3051ba22)): ?>
<?php $component = $__componentOriginalad01e5326b1985fd7ab2567e3051ba22; ?>
<?php unset($__componentOriginalad01e5326b1985fd7ab2567e3051ba22); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\OVE_Landing_Page_Deployment_Data\AU\CICD_SetUP\resources\views/landing_pages/siliconvalley.blade.php ENDPATH**/ ?>