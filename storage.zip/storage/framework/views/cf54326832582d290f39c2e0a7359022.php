<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'profile' => 'array',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'profile' => 'array',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="w-[100%] h-full flex-col">
    <div class="relative mt-20 bg-bacancy-primary rounded h-full overflow-visible z-10">
        <div class="mb-4 z-30 absolute top-0 start-0 end-0 insite-0 h-10 flex items-center justify-center">
            <div class="bg-white w-48 h-48 rounded-full overflow-visible">
                <img loading="lazy" class="w-full top-0 rounded-full mb-4 aspect-[1/1] object-cover bg-bacancy-lightblue p-1" src="<?php echo e(asset($profile['avtar'])); ?>" alt="<?php echo e($profile['name']); ?>" />
            </div>
        </div>
        <div class="p-6 h-100 pt-32 flex flex-col items-center justify-center">
            <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <h1 class="text-xl font-bold text-white"><?php echo e($profile['name']); ?></h1>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
            <p class="text-white text-xs mb-2"><?php echo e($profile['profile']); ?></p>
            <p class="text-white mb-1">PREVIOUSLY AT</p>
            <img loading="eager" fetchpriority="high" decoding="async" class="aspect-[2/1] object-container h-16 mb-2" src="<?php echo e(asset($profile['company_logo'])); ?>" alt="<?php echo e($profile['profile']); ?>"/>
            <div class="flex flex-wrap justify-center items-center gap-2">
                <?php
                    $lists = explode(',',$profile['tools']);
                ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span type="button" class="w-max px-4 rounded-full shadow !text-white !bg-black hover:!bg-gray-900 focus:!ring-gray-300"><?php echo e($item); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <p class="text-white mt-4 text-center text-xs line-clamp-2 leading-6" title="<?php echo e($profile['info'] ?? 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'); ?>">
                <?php echo e($profile['info'] ?? 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'); ?>

            </p>
        </div>
    </div>
    <!-- Nothing in life is to be feared, it is only to be understood. Now is the time to understand more, so that we may fear less. - Marie Curie -->
    <div class="bg-bacancy-primary hidden relative rounded-lg shadow-xl flex flex-col items-center justify-center mt-32">
        <div class="mb-4 relative insite-0 h-10 flex items-center justify-center">
            <div class="bg-white w-48 h-48 rounded-full overflow-hidden">
                <img loading="lazy" class="w-full top-0 rounded-full mb-4 aspect-[1/1] object-cover bg-bacancy-lightblue p-1" src="<?php echo e(asset($profile['avtar'])); ?>" alt="<?php echo e($profile['name']); ?>" />
            </div>
        </div>
        <div class="p-6 mt-10 flex flex-col items-center justify-center">
            <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <h1 class="text-xl font-bold text-white"><?php echo e($profile['name']); ?></h1>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
            <p class="text-white text-xs mb-2"><?php echo e($profile['profile']); ?></p>
            <p class="text-white mb-1">PREVIOUSLY</p>
            <img loading="eager" fetchpriority="high" decoding="async" class="aspect-[2/1] object-container h-16 mb-2" src="<?php echo e(asset($profile['company_logo'])); ?>" alt="<?php echo e($profile['profile']); ?>"/>
            <div class="flex flex-wrap justify-center items-center gap-2">
                <?php
                    $lists = explode(',',$profile['tools']);
                ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span type="button" class="w-max px-4 rounded-full shadow !text-white !bg-black hover:!bg-gray-900 focus:!ring-gray-300"><?php echo e($item); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <p class="text-white mt-4 text-center text-xs line-clamp-2" title="<?php echo e($profile['info'] ?? 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'); ?>">
                <?php echo e($profile['info'] ?? 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'); ?>

            </p>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lp4\resources\views/components/bacancypage/profile-card.blade.php ENDPATH**/ ?>