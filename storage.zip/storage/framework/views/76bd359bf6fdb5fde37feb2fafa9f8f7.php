<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['seo'=>['metaTitle' => '','metaDescription'=>'']]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['seo'=>['metaTitle' => '','metaDescription'=>'']]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="title" content="<?php echo e($seo['metaTitle']); ?>">
<meta name="description" content="<?php echo e($seo['metaDescription']); ?>">

<title><?php echo e($title ?? config('app.name')); ?></title>

<link rel="icon" href="<?php echo e(asset('/favicon.ico')); ?>" sizes="any">
<link rel="icon" href="<?php echo e(asset('/favicon.svg')); ?>" type="image/svg+xml">
<link rel="apple-touch-icon" href="<?php echo e(asset('/favicon.svg')); ?>">

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php echo app('flux')->fluxAppearance(); ?>

<!-- <link rel="stylesheet" href="<?php echo e(asset('build/assets/app-BtQ_9s-D.css')); ?>">
<script src="<?php echo e(asset('build/assets/app-l0sNRNKZ.js')); ?>" defer></script> -->

<!-- Google Tag Manager -->
<!-- <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5K42N2M2');</script> -->
<!-- End Google Tag Manager -->
<?php /**PATH C:\xampp\htdocs\lp4\resources\views/partials/head.blade.php ENDPATH**/ ?>