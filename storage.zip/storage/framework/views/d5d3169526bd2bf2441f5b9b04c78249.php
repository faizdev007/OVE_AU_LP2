<div class="py-12 bg-black scaling_team" section="scaling-team">

    


    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
        <div class="py-4">
            <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 border-bacancy-primary">
                <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
                <legend class="text-xl font-bold text-gray-900  markque px-2 text-white">Start Scaling Your Team section</legend>
                <p class="text-gray-600 dark:text-gray-400 text-white">update content of Start Scaling your team display!</p>
                    <div>
                        <form wire:submit.prevent="save" class="mt-2 p-1 flex-1 overflow-hidden max-w-7xl mx-auto ">
                        <div class="md:flex mb-3">
                            <input wire:model="title" type="text"
                                    class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2  border-bacancy-primary rounded-md w-full"
                                    placeholder="Title" />
                        </div>
                        <textarea wire:model="subtitle" rows="1" type="text"
                            class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2 border-bacancy-primary rounded-md w-full"
                            placeholder="SubTitle" ></textarea>
                        <div class="md:flex mb-3">
                            <input wire:model="formtitle" type="text"
                                    class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2  border-bacancy-primary rounded-md w-full"
                                    placeholder="Form Title" />
                        </div>
                        <textarea wire:model="formsubtitle" rows="1" type="text"
                            class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2 border-bacancy-primary rounded-md w-full"
                            placeholder="Form SubTitle" ></textarea>
                        <div class="md:flex mb-3 p-2 bg-bacancy-primary rounded-full w-max px-8">
                            <input wire:model="formbtntext" type="text"
                                    class="bg-white md:text-md w-max bg-white xl:text-xl sm:text-sm text-xs text-black border p-0 px-2  border-bacancy-primary rounded-md w-full"
                                    placeholder="Button Text" />
                        </div>
                        <fieldset class="mb-4 border-2 border-white p-4">
                            <legend class="font-bold text-white">Points Show</legend>
                            <div class="grid md:grid-cols-3 gap-4">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <div class="border bg-white p-4 col-span-2 rounded flex flex-col text-black justify-between shadow relative">

                                            
                                            <div class="text-right">
                                                <!--[if BLOCK]><![endif]--><?php if(count($points) > 1): ?>
                                                    <button type="button" wire:click="removepoint(<?php echo e($index); ?>)"
                                                        class="absolute top-0 end-0 bg-red-500 text-white h-8 w-8 rounded hover:bg-red-600">
                                                        X
                                                    </button>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>

                                            <div class="mt-5">
                                                <input type="text" wire:model.defer="points.<?php echo e($index); ?>.title"
                                                    placeholder="Point Title" class="w-full mb-2 border p-2 rounded" />
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["points.$index.title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                                <textarea wire:model.defer="points.<?php echo e($index); ?>.subtitle" rows="2"
                                                    placeholder="Point Subtitle" class="w-full mb-2 border p-2 rounded"></textarea>
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["points.$index.subtitle"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            
                            <button type="button" wire:click="addpoint"
                                class="mt-4 bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700">
                                + Add Point
                            </button>
                        </fieldset>
                        <!-- Save Button -->
                        <div class="absolute -top-10 px-2 end-0 flex justify-center">
                            <button type="submit" wire:loading.attr="disabled" class="px-6 py-3 cursor-pointer bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                                <span wire:loading wire:target="save">saving...</span>
                                <span wire:loading.remove wire:target="save">Save</span>
                            </button>
                        </div>
                    </form>
                </div>
            </fieldset>
        </div>
    <?php else: ?>
    <div class="relative md:flex grid gap-4 px-4 py-2 sm:px-6 lg:px-8 overflow-hidden mx-auto ">
        <div class="flex-1 gap-8 my-5 flex w-full flex-col mx-auto text-white">
            <div class="gap-4 flex flex-col">
                <h2 class="md:text-3xl text-2xl font-bold"><?php echo e($title); ?></h2>
                <p><?php echo e($subtitle); ?></p>
            </div>
            <div class="flex flex-row gap-3">
                <div class="flex flex-col">
                    <div class="pt-1 flex gap-2">
                        <span class="h-10 w-10 mt-2 md:mt-1 rounded-full flex justify-center items-center bg-white text-black font-bold text-2xl">1</span>
                        <div class="flex-1">
                            <h3 class="md:text-2xl text-xl font-bold">Submit Your Details</h3>
                            <p class="md:text-sm text-xs">Your privacy is our priority, and your information is safe with us.</p>
                        </div>
                    </div>
                    <!-- Line Between -->
                    <div class="md:h-16 h-10 w-1 bg-white mx-[18px]"></div>
                    
                    <div class="flex gap-2">
                        <span class="h-10 w-10 mt-2 rounded-full flex justify-center items-center bg-white text-black font-bold text-2xl">2</span>
                        <div class="flex-1">
                            <h3 class="md:text-2xl text-xl font-bold">What Happens Next?</h3>
                            <p class="md:text-sm text-xs">A Growth Manager will reach out to you shortly.</p>
                            <div class="flex flex-row gap-2">
                                <img loading="lazy" src="<?php echo e(asset('assets/gm1.webp')); ?>" alt="Call" class="h-12 mt-2">
                                <img loading="lazy" src="<?php echo e(asset('assets/gm2.webp')); ?>" alt="Call" class="h-12 mt-2">
                                <img loading="lazy" src="<?php echo e(asset('assets/gm3.webp')); ?>" alt="Call" class="h-12 mt-2">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex-1 w-full text-white text-center">
            <h2 class="text-3xl mb-4 xl:text-[45px] font-extrabold"><?php echo e($formtitle); ?></h2>
            <h4 class="text-lg mb-4 xl:text-[20px]"><?php echo e($formsubtitle); ?></h4>
            <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
            <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
                <div 
                    x-data="{ show: true }" 
                    x-init="setTimeout(() => show = false, 3000)" 
                    x-show="show"
                    class="bg-green-100 text-green-800 px-3 py-2 rounded mb-3 transition-opacity duration-500"
                >
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <?php if(session()->has('error')): ?>
                <div 
                    x-data="{ show: true }" 
                    x-init="setTimeout(() => show = false, 3000)" 
                    x-show="show"
                    class="bg-red-100 text-red-800 px-3 py-2 rounded mb-3 transition-opacity duration-500"
                >
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <form wire:submit.prevent="submitquery">
                <input type="text" wire:model.defer="name" id="name" placeholder="Name"
                    class="p-4 border boreder-white font-bold flex-1 w-full mb-4 focus:ring-0 focus:border-bacancy-primary" autocomplete="true" required />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                <div class="flex gap-4 mb-4">
                    <input type="email" wire:model.defer="email" id="email" placeholder="Email"
                        class="p-4 border boreder-white font-bold flex-1 w-full mb-4 focus:ring-0 focus:border-bacancy-primary" autocomplete="true" required />    
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    <input type="tel" wire:model.defer="phone" id="phone" placeholder="Phone"   
                        inputmode="numeric" 
                        pattern="\d*" 
                        required
                        oninput="this.value = this.value.replace(/[^0-9]/g, '')" 
                        maxlength="14" 
                        autocomplete="true"
                        class="p-4 border boreder-white font-bold flex-1 w-full mb-4 focus:ring-0 focus:border-bacancy-primary" required />
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <textarea wire:model.defer="project_brief" id="project_brief" placeholder="Requirement" rows="3"
                    class="p-4 border boreder-white font-bold flex-1 w-full mb-4 focus:ring-0 focus:border-bacancy-primary" autocomplete="true" required></textarea>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["project_brief"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                <div class="relative flex items-center justify-center">
                    <?php if (isset($component)) { $__componentOriginal13113c9f32f6116c43cb9fbecee94495 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13113c9f32f6116c43cb9fbecee94495 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.submit-button','data' => ['type' => 'submit','title' => ''.e($formbtntext).'','target' => 'submitquery','class' => '!text-black w-max !md:text-2xl !bg-white hover:!bg-gray-900 hover:!text-white focus:!ring-[#000000]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','title' => ''.e($formbtntext).'','target' => 'submitquery','class' => '!text-black w-max !md:text-2xl !bg-white hover:!bg-gray-900 hover:!text-white focus:!ring-[#000000]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $attributes = $__attributesOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $component = $__componentOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__componentOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\OVE_Landing_Page_Deployment_Data\AU\CICD_SetUP\resources\views/livewire/bacancypage/start-scaling-your-team.blade.php ENDPATH**/ ?>