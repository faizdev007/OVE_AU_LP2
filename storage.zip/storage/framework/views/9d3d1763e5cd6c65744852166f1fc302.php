<div class="py-12 scroll-mt-20 bg-bacancy-primary" section="AI-ET">
    
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
        <div class="py-4">
            <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 bg-gray-100 border-black">
                <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
                <legend class="text-xl font-bold text-gray-900  bg-gray-100 border border-black markque px-2">AI-Enhanced-Talent</legend>
                <p class="text-gray-600">Customize the AI-Enhanced-Talent section of your Bacancy landing page.</p>
                <form x-data="{
                        logopreview: null,
                        ai_logopreview: [null, null, null],
                        previewImage(event, index, isSingle = false) {
                            const file = event.target.files[0];
                            if (!file) return;
                            const reader = new FileReader();
                            reader.onload = e => {
                                if (isSingle) {
                                    this.logopreview = e.target.result;
                                } else {
                                    this.ai_logopreview[index] = e.target.result;
                                }
                            };
                            reader.readAsDataURL(file);
                        }
                    }" wire:submit.prevent="save" class="mt-2 flex-1 overflow-hidden max-w-7xl mx-auto ">
                    <div class="md:flex mb-3">
                        <input wire:model="aiblock_title" type="text"
                                class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2  border-bacancy-primary rounded-md w-full"
                                placeholder="Title" />
                    </div>
                    <input wire:model="aiblock_watchword" type="text"
                                class="bg-white md:text-md mb-3 xl:text-xl sm:text-sm text-xs text-black border p-2  border-bacancy-primary rounded-md w-full"
                                placeholder="watchword" />

                    <textarea wire:model="aiblock_subtitle" rows="2" type="text"
                        class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2 border-bacancy-primary rounded-md w-full"
                        placeholder="SubTitle" ></textarea>

                    <div class="md:flex mb-3 p-2 bg-bacancy-primary rounded-full w-max px-8">
                        <input wire:model="btntext" type="text"
                                class="bg-white md:text-md w-max bg-white xl:text-xl sm:text-sm text-xs text-black border p-0 px-2  border-bacancy-primary rounded-md w-full"
                                placeholder="Button Text" />
                    </div>
                    
                    <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 bg-gray-100 border-black flex md:flex-row flex-col  justify-center items-center gap-2 mt-2">
                        <legend class="text-xl font-bold text-gray-900  bg-gray-100 border border-black markque px-2">AI Images Display Block</legend>

                        
                        <div class="w-32 aspect-square bg-white aspect-[1/1] relative border-2 border-dashed rounded-lg flex items-center justify-center">
                            <template x-if="logopreview">
                                <img :src="logopreview" class="absolute inset-0 p-4 aspect-square object-container w-full h-full rounded-lg" />
                            </template>
                            <input 
                                type="file" 
                                accept=".webp"
                                wire:model="logo_webp"
                                class="absolute inset-0 opacity-0 cursor-pointer"
                                @change="previewImage($event, null, true)"
                            />
                            <span class="text-gray-400 text-xs aspect-[1/1]" x-show="!logopreview">
                                <!--[if BLOCK]><![endif]--><?php if($logo_webp): ?>
                                    <img src="<?php echo e(asset($logo_webp)); ?>" class="aspect-square object-container" />
                                <?php else: ?>
                                    1:1
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </span>
                        </div>

                        
                        <div class="bg-white h-18 p-4 rounded-lg flex items-center justify-center aspect-[2/1] relative border-2 border-dashed">
                            <template x-if="ai_logopreview[0]">
                                <img :src="ai_logopreview[0]" class="absolute p-4 aspect-[2/1] object-container" />
                            </template>
                            <input 
                                type="file" 
                                accept=".webp"
                                wire:model="ai_logo_one"
                                class="absolute inset-0 opacity-0 cursor-pointer"
                                @change="previewImage($event, 0)"
                            />
                            <span class="text-gray-400 bg-white text-xs" x-show="!ai_logopreview[0]">
                                <!--[if BLOCK]><![endif]--><?php if($ai_logo_one): ?>
                                    <img src="<?php echo e(asset($ai_logo_one)); ?>" class="aspect-[2/1] object-container" />
                                <?php else: ?>
                                    2:1 #1
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </span>
                        </div>

                        
                        <div class="bg-white h-18 p-4 rounded-lg flex items-center justify-center aspect-[2/1] relative border-2 border-dashed">
                            <template x-if="ai_logopreview[1]">
                                <img :src="ai_logopreview[1]" class="absolute p-4 aspect-[2/1] object-container" />
                            </template>
                            <input 
                                type="file" 
                                accept=".webp"
                                wire:model="ai_logo_two"
                                class="absolute inset-0 opacity-0 cursor-pointer"
                                @change="previewImage($event, 1)"
                            />
                            <span class="text-gray-400 bg-white text-xs" x-show="!ai_logopreview[1]">
                                <!--[if BLOCK]><![endif]--><?php if($ai_logo_two): ?>
                                    <img src="<?php echo e(asset($ai_logo_two)); ?>" class="aspect-[2/1] object-container" />
                                <?php else: ?>
                                    2:1 #2
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </span>
                        </div>

                        
                        <div class="bg-white h-18 p-4 rounded-lg flex items-center justify-center aspect-[2/1] relative border-2 border-dashed">
                            <template x-if="ai_logopreview[2]">
                                <img :src="ai_logopreview[2]" class="absolute p-4 aspect-[2/1] object-container" />
                            </template>
                            <input 
                                type="file" 
                                accept=".webp"
                                wire:model="ai_logo_three"
                                class="absolute inset-0 opacity-0 cursor-pointer"
                                @change="previewImage($event, 2)"
                            />
                            <span class="text-gray-400 bg-white text-xs" x-show="!ai_logopreview[2]">
                                <!--[if BLOCK]><![endif]--><?php if($ai_logo_three): ?>
                                    <img src="<?php echo e(asset($ai_logo_three)); ?>" class="aspect-[2/1] object-container" />
                                <?php else: ?>
                                    2:1 #3
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </span>
                        </div>
                    </fieldset>

                    <!-- Save Button -->
                    <div class="absolute -top-10 px-2 end-0 flex justify-center">
                        <button type="submit" wire:loading.attr="disabled" class="px-6 py-3 bg-black cursor-pointer text-white rounded-full hover:bg-gray-800 transition">
                            <span wire:loading wire:target="save">saving...</span>
                            <span wire:loading.remove wire:target="save">Save</span>
                        </button>
                    </div>
                </form>
            </fieldset>
        </div>
    <?php else: ?>
    <div class="relative md:flex grid flex-1 gap-4 px-4 py-2 sm:px-6 lg:px-8 overflow-hidden mx-auto ">
        <div class="w-full flex-1 flex pt-10 justify-between flex-col mx-auto">
            <div class="flex flex-col gap-5">
                <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['class' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>
                    <h2 class="xl:text-3xl font-[900] text-white"><?php echo e($aiblock_title); ?></h2>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
                <p class="mt-2 text-white text-3xl !font-[400] xl:text-4xl mb-6"><?php echo e($aiblock_watchword); ?></p>
                <p class="text-white text-lg xl:text-xl md:text-sm mb-6"><?php echo e($aiblock_subtitle); ?></p>
            </div>
            <?php if (isset($component)) { $__componentOriginal1db8c57e729d67f7d4103875cf3230cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.trigger','data' => ['name' => 'book-a-call']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal.trigger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book-a-call']); ?>
                <?php if (isset($component)) { $__componentOriginale9eefe50b390207aad69b8e237e3dc7d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9eefe50b390207aad69b8e237e3dc7d = $attributes; } ?>
<?php $component = App\View\Components\ActionButton::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ActionButton::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'open-modal\', \'book-a-call\')','title' => ''.e($btntext).'','class' => '!text-white w-max !bg-black hover:!bg-gray-800 2xl:text-[1.5rem] focus:!ring-[#000000]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9eefe50b390207aad69b8e237e3dc7d)): ?>
<?php $attributes = $__attributesOriginale9eefe50b390207aad69b8e237e3dc7d; ?>
<?php unset($__attributesOriginale9eefe50b390207aad69b8e237e3dc7d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9eefe50b390207aad69b8e237e3dc7d)): ?>
<?php $component = $__componentOriginale9eefe50b390207aad69b8e237e3dc7d; ?>
<?php unset($__componentOriginale9eefe50b390207aad69b8e237e3dc7d); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $attributes = $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $component = $__componentOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
        </div>
        <div class="flex-1 w-full flex items-center justify-center relative">
            <div class="relative rounded-lg shadow-lg overflow-hidden bg-white aspect-square items-center flex p-4 gap-6">
                <div class="flex flex-1 items-center justify-center w-full">
                    <img loading="eager" decoding="async" src="<?php echo e(asset($logo_webp)); ?>" alt="Optimal Vertual Employee" class="aspect-square object-container"/>
                </div>
                <div class="text-black font-bold text-lg flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="size-6">
                        <path d="M8.75 3.75a.75.75 0 0 0-1.5 0v3.5h-3.5a.75.75 0 0 0 0 1.5h3.5v3.5a.75.75 0 0 0 1.5 0v-3.5h3.5a.75.75 0 0 0 0-1.5h-3.5v-3.5Z" />
                    </svg>
                </div>
                <div class="flex-1 w-full flex flex-col justify-around gap-6 items-center">
                    <div class="bg-white xl:w-32 w-24 border h-18 p-4 rounded-lg shadow-lg me-10 flex items-center justify-center">
                        <img loading="lazy" decoding="async" src="<?php echo e(asset($ai_logo_one)); ?>" alt="AI Image One" class="object-container" />
                    </div>
                    <div class="bg-white xl:w-32 w-24 border h-18 p-4 rounded-lg shadow-lg ms-10 flex items-center justify-center">
                        <img loading="lazy" decoding="async" src="<?php echo e(asset($ai_logo_two)); ?>" alt="AI Image One" class="object-container" />
                    </div>
                    <div class="bg-white xl:w-32 w-24 border h-18 p-4 rounded-lg shadow-lg me-10 flex items-center justify-center">
                        <img loading="lazy" decoding="async" src="<?php echo e(asset($ai_logo_three)); ?>" alt="AI Image One" class="object-container" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\xampp\htdocs\lp4\resources\views/livewire/bacancypage/ai-block.blade.php ENDPATH**/ ?>