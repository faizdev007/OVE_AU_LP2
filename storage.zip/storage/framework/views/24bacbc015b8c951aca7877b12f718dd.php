<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'project' => 'array',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'project' => 'array',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="relative">
    <!-- Happiness is not something readymade. It comes from your own actions. - Dalai Lama -->
    <div class="grid lg:grid-cols-4 grid-cols-1 lg:gap-1 gap-y-1 lg:gap-y-0 items-center justify-center w-full">
        <div class="bg-white text-black border border-black p-4 h-full text-start flex flex-col gap-6 rounded">
            <span class="md:text-md text-xs 2xl:text-xl border rounded-full bg-bacancy-primary w-max text-white p-3"><?php echo e($project['label_tag']); ?></span>
            <div class="flex flex-col gap-2">
                <h3 class="md:text-2xl 2xl:text-3xl font-bold"><?php echo e($project['project_name']); ?></h3>
                <p class="md:text-md 2xl:text-2xl text-xs"><?php echo e($project['brief_detail']); ?></p>
            </div>
            <ul class="overflow-auto lg:h-32 h-48 2xl:h-full text-xs 2xl:text-xl space-y-4 w-full no-scrollbar list-disc list-inside">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $project['highlights']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($point); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        </div>  
        <div class="bg-white border border-black h-full col-span-3 w-full flex items-center justify-center xl:px-18 rounded">
            <img src="<?php echo e(asset($project['web_pic'] ?? 'assets/bacancy/logo2.webp')); ?>" alt="Project Logo" class="w-full object-container">
        </div>
    </div>
</div><?php /**PATH /home3/oveau/public_html/resources/views/components/bacancypage/project-card.blade.php ENDPATH**/ ?>