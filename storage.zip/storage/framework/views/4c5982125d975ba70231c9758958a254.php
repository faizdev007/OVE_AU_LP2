<div class="my-12 scroll-mt-20" id="724" section="tech-stack">
    
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
        <div class="py-4">
            <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 border-bacancy-primary">
                <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>


                <legend class="text-xl font-bold text-gray-900  markque px-2">Technical Stack</legend>
                <p class="text-gray-600 dark:text-gray-400">This is technical stack area</p>
                    <div>
                        <form wire:submit.prevent="save" class="mt-2 p-1 flex-1 overflow-hidden max-w-7xl mx-auto ">
                        <div class="md:flex mb-3">
                            <input wire:model="title" type="text"
                                    class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2  border-bacancy-primary rounded-md w-full"
                                    placeholder="Title" />
                        </div>
                        <textarea wire:model="subtitle" rows="2" type="text"
                            class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2 border-bacancy-primary rounded-md w-full"
                            placeholder="SubTitle" ></textarea>
                        
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $techIconSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectionIndex => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <fieldset class="mb-6 border-2 border-black p-4 relative">
                                    <legend class="text-gray-600 dark:text-gray-400 font-bold">Tech Icon Section</legend>
                                       <div class="text-right">
                                        <!--[if BLOCK]><![endif]--><?php if(count($section) > 1): ?>
                                            <button type="button"
                                                    wire:click="removeSection(<?php echo e($sectionIndex); ?>)"
                                                    class="absolute -top-6 -end-1 bg-red-500 text-white h-8 w-8 rounded hover:bg-red-600">X</button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    
                                    <input type="text"
                                        wire:model.defer="techIconSections.<?php echo e($sectionIndex); ?>.title"
                                        placeholder="Section Title"
                                        class="w-full mb-4 text-black border p-2 rounded" />
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["techIconSections.$sectionIndex.title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-red-500"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                    <div class="grid md:grid-cols-5 gap-4">
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $section['elements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elementIndex => $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div>
                                                <div class="border p-4 rounded flex flex-col text-black shadow relative">
                                                    
                                                    <div class="text-right">
                                                        <!--[if BLOCK]><![endif]--><?php if(count($section['elements']) > 1): ?>
                                                            <button type="button"
                                                                    wire:click="removeElement(<?php echo e($sectionIndex); ?>, <?php echo e($elementIndex); ?>)"
                                                                    class="absolute -top-2 -end-2 bg-red-500 text-white h-6 w-6 rounded-full hover:bg-red-600">X</button>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>

                                                    <label class="object-container mb-2">
                                                            <div class="w-full flex-col aspect-[2/1] p-1 flex items-center justify-center bg-gray-200 mb-2">
                                                                <div wire:loading wire:target="techIconSections.<?php echo e($sectionIndex); ?>.elements.<?php echo e($elementIndex); ?>.icon" class="text-sm text-gray-500">Uploading...</div>
                                                                <!--[if BLOCK]><![endif]--><?php if(isset($element['icon']) && is_object($element['icon'])): ?>
                                                                    <img wire:loading.remove wire:target="techIconSections.<?php echo e($sectionIndex); ?>.elements.<?php echo e($elementIndex); ?>.icon" src="<?php echo e($element['icon']->temporaryUrl()); ?>" class="w-full p-1 rounded mb-2" />
                                                                <?php elseif($element['icon'] && !is_object($element['icon'])): ?>
                                                                    <img wire:loading.remove wire:target="techIconSections.<?php echo e($sectionIndex); ?>.elements.<?php echo e($elementIndex); ?>.icon" src="<?php echo e(asset($element['icon'])); ?>" class="w-full p-1 rounded mb-2" />
                                                                <?php else: ?>
                                                                    <div class="text-center" wire:loading.remove wire:target="techIconSections.<?php echo e($sectionIndex); ?>.elements.<?php echo e($elementIndex); ?>.icon">
                                                                        <p class="mb-0 pb-0">Tech Icon</p>
                                                                        <span class="text-xs">(Only Webp)</span>
                                                                    </div>
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            </div>

                                                        
                                                        <input type="file"
                                                            wire:model="techIconSections.<?php echo e($sectionIndex); ?>.elements.<?php echo e($elementIndex); ?>.icon"
                                                            wire:change="removeIcon(<?php echo e($sectionIndex); ?>,<?php echo e($elementIndex); ?>)"
                                                            accept="image/webp"
                                                            class="w-full hidden mb-2 border p-2 rounded" />
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["techIconSections.$sectionIndex.elements.$elementIndex.icon"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-red-500"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                    </label>

                                                    
                                                    <input type="text"
                                                        wire:model.defer="techIconSections.<?php echo e($sectionIndex); ?>.elements.<?php echo e($elementIndex); ?>.name"
                                                        placeholder="Name"
                                                        class="w-full mb-2 border p-2 rounded" />
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["techIconSections.$sectionIndex.elements.$elementIndex.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-red-500"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    
                                    <button type="button"
                                            wire:click="addElement(<?php echo e($sectionIndex); ?>)"
                                            class="mt-4 bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700">
                                        + Add More Tech Icon
                                    </button>
                                </fieldset>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                            
                            <button type="button"
                                    wire:click="addSection"
                                    class="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                                + Add New Section
                            </button>
                        
                            <!-- Save Button -->
                            <div class="absolute -top-10 px-2 end-0 flex justify-center">
                                <button type="submit" wire:loading.attr="disabled" class="px-6 cursor-pointer py-3 bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                                    <span wire:loading wire:target="save">saving...</span>
                                    <span wire:loading.remove wire:target="save">Save</span>
                                </button>
                            </div>
                    </form>
                </div>
            </fieldset>
        </div>
    <?php else: ?>
    <div class="relative flex-1 gap-4 px-4 sm:px-6 lg:px-8 overflow-hidden mx-auto ">
        <div class="w-full max-w-5xl mx-auto">
            <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <h2 class="text-2xl xl:text-[45px] font-extrabold text-gray-900 "><?php echo e($title); ?></h2>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::subheading','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::subheading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <p class="mt-2 text-black xl:text-xl md:text-sm  mb-6"><?php echo e($subtitle); ?></p>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $attributes = $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $component = $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
        </div>
        <div class="overflow-hidden relative">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $techIconSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="md:flex 2xl:text-2xl mb-4 border-2 border-black justify-center w-full items-center shadow">
                    <div class="bg-bacancy-primary md:w-68 w-full border-2 font-bold border-bacancy-primary text-white p-4"><?php echo e($category['title']); ?></div>
                    <div class="flex font-bold text-black divide-x divide-black no-scrollbar overflow-x-auto md:flex-1">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $category['elements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--[if BLOCK]><![endif]--><?php if($item['icon']): ?>
                                <div class="flex flex-col w-24 px-2 aspect-[2/1] py-4 relative">
                                    <img loading="lazy" src="<?php echo e($item['icon']); ?>" class="aspect-[2/1] h-6 w-full object-container" alt="<?php echo e($item['name']); ?>"/>
                                    <span class="px-3 text-[10px] text-nowrap absolute bottom-0 end-0"><?php echo e($item['name']); ?></span>
                                </div>
                            <?php else: ?>   
                                 <div class="px-4 flex h-full items-center justify-center text-nowrap p-4"><?php echo e($item['name']); ?></div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\lp4\resources\views/livewire/bacancypage/tech-stack.blade.php ENDPATH**/ ?>