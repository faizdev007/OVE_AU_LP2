<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['rows' => '3']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['rows' => '3']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div <?php echo e($attributes->merge(['class' => 'p-6'])); ?>>
    
    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div 
            x-data="{ show: true }" 
            x-init="setTimeout(() => show = false, 3000)" 
            x-show="show"
            class="bg-green-100 text-green-800 px-3 py-2 rounded mb-3 transition-opacity duration-500"
        >
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('error')): ?>
        <div 
            x-data="{ show: true }" 
            x-init="setTimeout(() => show = false, 3000)" 
            x-show="show"
            class="bg-red-100 text-red-800 px-3 py-2 rounded mb-3 transition-opacity duration-500"
        >
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form wire:submit.prevent="submitquery">
        <div class="my-4">
            <label for="name" class="block text-sm font-medium mb-1 hidden">Full Name</label>
            <input type="text" autocomplete="true" id="name" wire:model.defer="name" class="w-full border-0 border-b border-white bg-transparent px-3 py-2 text-white placeholder-white focus:outline-none focus:ring-0 focus:border-white" placeholder="Full Name"/>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        
        <div class="md:flex gap-4">
            <div class="my-4">
                <label for="email" class="block text-sm font-medium mb-1 hidden">Email</label>
                <input type="email" autocomplete="true" id="email" placeholder="Email" wire:model.defer="email" class="w-full border-0 border-b border-white bg-transparent px-3 py-2 text-white placeholder-white focus:outline-none focus:ring-0 focus:border-white"/>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="my-4">
                <label for="phone" class="block text-sm font-medium mb-1 hidden">phone</label>
                <input type="phone" autocomplete="true" id="phone" placeholder="Phone" wire:model.defer="phone"
                inputmode="numeric" 
                pattern="\d*" 
                required
                oninput="this.value = this.value.replace(/[^0-9]/g, '')" 
                maxlength="14"
                class="w-full border-0 border-b border-white bg-transparent px-3 py-2 text-white placeholder-white focus:outline-none focus:ring-0 focus:border-white"/>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="my-4">
            <label for="project_brief" class="block text-sm font-medium mb-1 hidden">Project Brief</label>
            <textarea type="text" rows="<?php echo e($rows); ?>" id="project_brief" placeholder="Project Brief" wire:model.defer="project_brief" class="w-full border-0 border-b border-white bg-transparent px-3 py-2 text-white placeholder-white focus:outline-none focus:ring-0 focus:border-white"></textarea>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['projectBrief'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="flex justify-center space-x-2">
            <?php if (isset($component)) { $__componentOriginal13113c9f32f6116c43cb9fbecee94495 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13113c9f32f6116c43cb9fbecee94495 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.submit-button','data' => ['type' => 'submit','title' => 'Book a 30 mins strategy call','target' => 'submitquery','class' => '!text-black w-max !md:text-2xl !bg-white hover:!bg-gray-900 hover:!text-white focus:!ring-[#000000]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','title' => 'Book a 30 mins strategy call','target' => 'submitquery','class' => '!text-black w-max !md:text-2xl !bg-white hover:!bg-gray-900 hover:!text-white focus:!ring-[#000000]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $attributes = $__attributesOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $component = $__componentOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__componentOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
        </div>
    </form>
</div><?php /**PATH /home3/oveau/public_html/resources/views/livewire/request-form.blade.php ENDPATH**/ ?>