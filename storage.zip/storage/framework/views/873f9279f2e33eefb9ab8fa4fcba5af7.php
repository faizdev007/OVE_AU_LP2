<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['buttonText' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['buttonText' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div>
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
    
    <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
    <form wire:submit.prevent="savemodal" >
        <div class="md:flex md:p-0 py-4 items-start justify-between">
            <div class="flex-1 w-full aspect-[1/1] relative md:block hidden">
            <img loading="eager" fetchpriority="high" decoding="async" src="<?php echo e(asset('assets/modalpic2.webp')); ?>" alt="book_a_30_mins_strategy_call" height="500px" width="500px" class="w-full h-full object-cover" />
            <div class="bg-black/50 absolute top-0 bottom-0 start-0 end-0 z-10"></div>
                <div class="absolute top-0 bottm-0 start-0 end-0 z-20 flex flex-col justify-around h-full gap-3 p-4 text-white">
                    <input type="text" class="md:text-2xl text-xl text-center" wire:model="title" placeholder="<?php echo e($title); ?>"/>
                    <ul>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex gap-2 items-center">
                                <!-- Checkmark icon -->
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-5 text-green-500">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z" clip-rule="evenodd" />
                                </svg>
    
                                <!-- Text input -->
                                <input 
                                    type="text" 
                                    class="w-full text-white" 
                                    wire:model="lists.<?php echo e($key); ?>" 
                                    placeholder="Enter item..."
                                />
    
                                <!-- Remove Button -->
                                <button
                                    type="button" 
                                    wire:click="removeItem(<?php echo e($key); ?>)"
                                    class="text-red-500 hover:text-red-700 font-bold"
                                >
                                    ✕
                                </button>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
    
                    <!-- Add Button -->
                    <button 
                        type="button"
                        wire:click="addItem"
                        class="bg-blue-500 text-white rounded px-3 py-1 mt-2 hover:bg-blue-600"
                    >
                        + Add Item
                    </button>
                    <div class="grid gap-2">
                        <input type="text" wire:model="stacktitle" placeholder="<?php echo e($stacktitle); ?>"/>
                        <div class="grid grid-cols-4 gap-4">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $stack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="rounded relative space-y-2">
                                    <input type="text" class="font-bold uppercase w-full" wire:model="stack.<?php echo e($key); ?>.title" placeholder="Title"/>
                                    <input type="text" class="w-full" wire:model="stack.<?php echo e($key); ?>.description" placeholder="Value"/>
    
                                    <button 
                                        type="button"
                                        wire:click="removeStack(<?php echo e($key); ?>)"
                                        class="text-red-500 hover:text-red-700 font-bold absolute -top-3 end-0 px-1"
                                    >
                                        ✕
                                    </button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
    
                        <!-- Add New Item Button -->
                        <button 
                            type="button"
                            wire:click="addStack"
                            class="bg-blue-500 text-white rounded px-3 py-1 mt-3 hover:bg-blue-600"
                        >
                            + Add New Item
                        </button>
    
                    </div>
                    <label class="w-full flex justify-start">
                        <!-- Image Preview -->
                        <!--[if BLOCK]><![endif]--><?php if($image): ?>
                            <img 
                                wire:loading.remove
                                wire:target="image"
                                src="<?php echo e($image->temporaryUrl()); ?>" 
                                alt="Uploaded Preview" 
                                class="h-14 rounded"
                            />
                        <?php else: ?>
                            <img 
                                wire:loading.remove
                                wire:target="image"
                                loading="lazy" 
                                decoding="async" 
                                src="<?php echo e(asset($old_path)); ?>" 
                                alt="google rating" 
                                class="h-14"
                            />
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <span wire:loading wire:target="image">Loading....</span>
    
                        <!-- File Input -->
                        <input 
                            type="file" 
                            wire:model="image"
                            accept="image/*"
                            class="border hidden rounded p-1"
                        />
    
                        <!-- Optional Validation Messages -->
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <span class="text-red-600 text-sm"><?php echo e($message); ?></span> 
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </label>
                </div>
            </div>
            <div class="flex-1 w-full my-4 text-center md:py-0">
                <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['center' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['center' => true]); ?>
                    <input type="text" class="text-xl md:text-3xl font-bold w-full text-white text-center px-6" wire:model="formtitle" placeholder="<?php echo e($formtitle); ?>"/>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
                <input type="text" class="md:text-xl text-md text-center py-2 w-full  text-white" wire:model="formsubtitle" placeholder="<?php echo e($formsubtitle); ?>"/>
                <!-- Save Button -->
            </div>
        </div>
        <div class="flex justify-center">
            <button class="p-2 w-full my-2 cursor-pointer bg-bacancy-primary text-white rounded hover:bg-blue-600 transition">
                <span wire:loading wire:target="savemodal">saving...</span>
                <span wire:loading.remove wire:target="savemodal">Save</span>
            </button>
        </div>
    </form>
    <?php else: ?>
    <div class="md:flex md:p-0 py-4 items-center justify-between">
        <div class="flex-1 w-full aspect-[1/1] relative md:block hidden">
            <img loading="eager" fetchpriority="high" decoding="async" src="<?php echo e(asset('assets/modalpic2.webp')); ?>" alt="book_a_30_mins_strategy_call" height="500px" width="500px" class="w-full h-full object-cover" />
            <div class="bg-black/50 absolute top-0 bottom-0 start-0 end-0 z-10"></div>
            <div class="absolute top-0 bottm-0 start-0 end-0 z-20 flex flex-col justify-around h-full gap-3 p-4 text-white">
                <h2 class="md:text-2xl text-xl text-center"><?php echo e($title); ?></h2>
                <ul>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex gap-2 items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-5 text-green-500">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z" clip-rule="evenodd" />
                        </svg>
                        <?php echo e($item); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
                <div class="grid gap-2">
                    <h4><?php echo e($stacktitle); ?></h4>
                    <div class="grid grid-cols-4 gap-2">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $stack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="">
                            <h3 class="font-bold uppercase"><?php echo e($single['title']); ?></h3>
                            <p><?php echo e($single['description']); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="w-full flex justify-start">
                    <img loading="lazy" decoding="async" src="<?php echo e(asset($old_path)); ?>" alt="google rating" class="h-14"/>
                </div>
            </div>
        </div>
        <div class="flex-1 w-full md:py-0">
            <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['center' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['center' => true]); ?>
                <h2 class="text-xl md:text-3xl font-bold  text-white text-center px-6"><?php echo e($formtitle); ?></h2>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
            <h2 class="md:text-xl text-md text-center py-2  text-white"><?php echo e($formsubtitle); ?></h2>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('request-form', ['buttonText' => $buttonText,'inputClass' => 'text-white']);

$__html = app('livewire')->mount($__name, $__params, 'lw-1400282400-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\lp4\resources\views/livewire/modal/silicon-valley.blade.php ENDPATH**/ ?>