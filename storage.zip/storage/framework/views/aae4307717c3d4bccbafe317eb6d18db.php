<div class="py-12 border-b border-white scroll-mt-20 bg-sv-gradient-bottomtop">
    
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
    <fieldset class="container relative text-white max-w-6xl p-4 rounded mx-auto border-2 border-white">
        <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
        <legend class="text-xl font-bold text-white  markque px-2">Developers Section</legend>
        <p>Customize the Developer Profile section of your SiliconValley landing page.</p>
        <form wire:submit.prevent="save" class="mt-2 flex-1 overflow-hidden max-w-7xl mx-auto dark:border-neutral-700">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $devProfile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="md:flex gap-4 mb-6 items-start border p-4 rounded-md relative bg-white dark:bg-neutral-800">

                    <!-- Remove Developer Button -->
                    <button type="button" wire:click="removeProfile(<?php echo e($key); ?>)" class="absolute top-1 end-0 bg-red-600 rounded-full right-2 text-white p-2 px-3 text-xs font-bold">
                        X
                    </button>

                    <!-- Image Section -->
                    <div class="flex flex-col items-center gap-2">
                        <label class="cursor-pointer relative group">
                            <!--[if BLOCK]><![endif]--><?php if(isset($value['image']) && is_object($value['image'])): ?>
                                <img src="<?php echo e($value['image']->temporaryUrl()); ?>" class="h-32 w-32 rounded-full object-cover border shadow-md" />
                            <?php elseif(!empty($value['image']) && !is_object($value['image'])): ?>
                                <img src="<?php echo e(asset($value['image'])); ?>" class="h-32 w-32 rounded-full object-cover border shadow-md" />
                            <?php else: ?>
                                <div class="h-32 w-32 rounded-full flex items-center justify-center bg-gray-200 text-gray-600 border shadow-md">
                                    Upload Image
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <input type="file"
                                wire:model="devProfile.<?php echo e($key); ?>.image"
                                accept=".webp"
                                class="hidden" />

                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["devProfile.$key.image"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-xs mt-1 block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </label>
                    </div>

                    <!-- Details Section -->
                    <div class="flex-1">
                        <div class="flex gap-2 mb-4">
                            <div class="flex-1 flex flex-col gap-2 mb-4">
                                <input type="text"
                                    wire:model="devProfile.<?php echo e($key); ?>.name"
                                    class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="Enter name" />
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["devProfile.$key.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="flex-1 flex flex-col gap-2 mb-4">
                                <input type="number"
                                    max="5"
                                    min="0"
                                    wire:model="devProfile.<?php echo e($key); ?>.starts"
                                    class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="Enter Rating" />
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["devProfile.$key.starts"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="flex-1 flex flex-col gap-2 mb-4">
                                <input type="text"
                                    wire:model="devProfile.<?php echo e($key); ?>.techStack"
                                    class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="Enter Rating" />
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["devProfile.$key.techStack"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>

                        <div class="flex flex-col gap-2 mb-4">
                            <?php if (isset($component)) { $__componentOriginal7c4cb1a0e99e51d7788902376025d47b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c4cb1a0e99e51d7788902376025d47b = $attributes; } ?>
<?php $component = App\View\Components\SimpleTextEditor::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-text-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SimpleTextEditor::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'devProfile['.e($key).'][description]','content' => ''.$value['description'] ?? ''.'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c4cb1a0e99e51d7788902376025d47b)): ?>
<?php $attributes = $__attributesOriginal7c4cb1a0e99e51d7788902376025d47b; ?>
<?php unset($__attributesOriginal7c4cb1a0e99e51d7788902376025d47b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c4cb1a0e99e51d7788902376025d47b)): ?>
<?php $component = $__componentOriginal7c4cb1a0e99e51d7788902376025d47b; ?>
<?php unset($__componentOriginal7c4cb1a0e99e51d7788902376025d47b); ?>
<?php endif; ?>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["devProfile.$key.description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Projects Section (Always 4) -->
                        <fieldset class="flex gap-4 flex-wrap p-3 rounded border">
                            <legend class="text-sm font-semibold mb-2">Developer Projects</legend>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $value['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectKey => $projectImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="flex flex-col items-center gap-1">
                                    <!--[if BLOCK]><![endif]--><?php if(isset($projectImage) && is_object($projectImage)): ?>
                                        <img src="<?php echo e($projectImage->temporaryUrl()); ?>" class="h-28 w-28 rounded object-cover border shadow-md" />
                                    <?php elseif(isset($projectImage) && !is_object($projectImage)): ?>
                                        <img src="<?php echo e(asset($projectImage)); ?>" class="h-28 w-28 rounded object-cover border shadow-md" />
                                    <?php else: ?>
                                        <div class="h-28 w-28 rounded flex items-center justify-center bg-gray-200 text-gray-600 border shadow-md">
                                            Upload
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <input type="file"
                                        wire:model="devProfile.<?php echo e($key); ?>.projects.<?php echo e($projectKey); ?>"
                                        accept=".webp"
                                        class="hidden" />

                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["devProfile.$key.projects.$projectKey"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </fieldset>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

            <!-- Add More Developer Button -->
            <div class="flex justify-center my-6">
                <button type="button" wire:click="addProfile" class="px-4 py-2 bg-green-500 text-white rounded-full hover:bg-green-600 transition">
                    + Add Developer
                </button>
            </div>

            <!-- Save Button -->
            <div class="absolute -top-10 px-2 end-0 flex justify-center">
                <button type="submit" wire:loading.attr="disabled" class="px-6 py-3 cursor-pointer bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                    <span wire:loading wire:target="save">saving...</span>
                    <span wire:loading.remove wire:target="save">Save</span>
                </button>
            </div>
        </form>
    </fieldset>   
    <?php else: ?>
    <?php if (isset($component)) { $__componentOriginal687c686bb5a85506176f4c42fb855745 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal687c686bb5a85506176f4c42fb855745 = $attributes; } ?>
<?php $component = App\View\Components\AutoSlider::resolve(['cardmd' => 1,'cardlg' => 1,'cardxl' => 1,'card2xl' => 1,'autoSlide' => true,'interval' => 6000] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auto-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AutoSlider::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $devProfile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal2131d7c7ab6483b025c7160ed4005340 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2131d7c7ab6483b025c7160ed4005340 = $attributes; } ?>
<?php $component = App\View\Components\SiliconValley\DevProfile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('silicon-valley.dev-profile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SiliconValley\DevProfile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['devProfile' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($value)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2131d7c7ab6483b025c7160ed4005340)): ?>
<?php $attributes = $__attributesOriginal2131d7c7ab6483b025c7160ed4005340; ?>
<?php unset($__attributesOriginal2131d7c7ab6483b025c7160ed4005340); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2131d7c7ab6483b025c7160ed4005340)): ?>
<?php $component = $__componentOriginal2131d7c7ab6483b025c7160ed4005340; ?>
<?php unset($__componentOriginal2131d7c7ab6483b025c7160ed4005340); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal687c686bb5a85506176f4c42fb855745)): ?>
<?php $attributes = $__attributesOriginal687c686bb5a85506176f4c42fb855745; ?>
<?php unset($__attributesOriginal687c686bb5a85506176f4c42fb855745); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal687c686bb5a85506176f4c42fb855745)): ?>
<?php $component = $__componentOriginal687c686bb5a85506176f4c42fb855745; ?>
<?php unset($__componentOriginal687c686bb5a85506176f4c42fb855745); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\OVE_Landing_Page_Deployment_Data\AU\CICD_SetUP\resources\views/livewire/silicon-valley/dev-profile.blade.php ENDPATH**/ ?>