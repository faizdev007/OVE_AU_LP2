<div class="py-12 bg-black text-white" section="our-office-location">
    
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
        <div class="py-4">
            <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 border-bacancy-primary">
                <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
                <legend class="text-xl font-bold text-gray-900  markque px-2 text-white">Our Office Locations section</legend>
                <p class="text-gray-600 dark:text-gray-400 text-white">update Our Office Locations display!</p>
                    <div>
                        <form wire:submit.prevent="save" class="mt-2 p-1 flex-1 overflow-hidden max-w-7xl mx-auto ">
                        <div class="md:flex mb-3">
                            <input wire:model="title" type="text"
                                    class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2  border-bacancy-primary rounded-md w-full"
                                    placeholder="Title" />
                        </div>
                        <div class="grid md:grid-cols-2 lg:grid-cols-4 lg:divide-x-2 divide-y-2 md:divide-y-0 divide-[#5b5b5b] px-4">
                        <?php
                            $locations = [
                                1=>['name' => 'Australia', 'image' => 'assets/location/AUSTRALIA.webp', 'address' => 'Level 15, 333 Collins St, Melbourne 3000, Victoria, Australia'],
                                2=>['name' => 'USA', 'image' => 'assets/location/USA.webp', 'address' => '109 Mojonera Court, Los Gatos, CA, USA 95032'],
                                3=>['name' => 'UK', 'image' => 'assets/location/UK.webp', 'address' => '4TH Floor, Rex House, 4-12 Regent Street, London SW1Y 4PE(UK)'],
                                4=>['name' => 'India', 'image' => 'assets/location/INDIA.webp', 'address' => 'B27, Sector 132, Noida, Uttar Pardesh 201301.'],
                            ];

                             // Sort by order values
                            $orderedLocations = collect($orders)
                                ->filter(fn($order) => !empty($order))
                                ->sort()
                                ->mapWithKeys(fn($order, $key) => [$key => $locations[$key]])
                                ->all();
                        ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orderedLocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex flex-col px-4 py-6" aria-labelledby="autralia-office">
                                <div class="flex gap-2 mb-4 items-center">
                                    <input type="text"  wire:model.defer="orders.<?php echo e($key); ?>"
                                    class="bg-white w-8 text-center text-xs text-black border p-1  border-bacancy-primary rounded-md"
                                    />
                                    <img loading="lazy" src="<?php echo e(asset($location['image'])); ?>" alt="Australia Office" class="aspect-[2/1] w-12 object-cover">
                                    <h2 class="font-bold"><?php echo e($location['name']); ?></h2>
                                </div>
                                <p class="text-sm"><?php echo e($location['address']); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                        <!-- Save Button -->
                        <div class="absolute -top-10 px-2 end-0 flex justify-center">
                            <button type="submit" wire:loading.attr="disabled" class="px-6 cursor-pointer py-3 bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                                <span wire:loading wire:target="save">saving...</span>
                                <span wire:loading.remove wire:target="save">Save</span>
                            </button>
                        </div>
                    </form>
                </div>
            </fieldset>
        </div>
    <?php else: ?>
    <div class="mx-auto space-y-10 sm:px-6 lg:px-8">
        <h2 class="font-bold md:text-5xl mb-10 sm:text-2xl text-xl text-center uppercase outlined-text"><?php echo e($title); ?></h2>

        <?php
            $locations = [
                1 => [
                    'name' => 'Australia',
                    'image' => 'assets/location/AUSTRALIA.webp',
                    'address' => 'Level 15, 333 Collins St, Melbourne 3000, Victoria, Australia'
                ],
                2 => [
                    'name' => 'USA',
                    'image' => 'assets/location/USA.webp',
                    'address' => '109 Mojonera Court, Los Gatos, CA, USA 95032'
                ],
                3 => [
                    'name' => 'UK',
                    'image' => 'assets/location/UK.webp',
                    'address' => '4TH Floor, Rex House, 4-12 Regent Street, London SW1Y 4PE(UK)'
                ],
                4 => [
                    'name' => 'India',
                    'image' => 'assets/location/INDIA.webp',
                    'address' => 'B27, Sector 132, Noida, Uttar Pradesh 201301.'
                ],
            ];
            $orderedLocations = collect($orders)
                ->filter(fn($order) => !empty($order))
                ->sort()
                ->mapWithKeys(fn($order, $key) => [$key => $locations[$key]])
                ->all();
        ?>

        <div class="grid md:grid-cols-2 lg:grid-cols-4 lg:divide-x-2 divide-y-2 md:divide-y-0 divide-[#5b5b5b] px-4">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orderedLocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col px-4 py-6" aria-labelledby="<?php echo e(strtolower($order['name'])); ?>">
                    <div class="flex gap-2 mb-4 items-center">
                        <img loading="lazy" src="<?php echo e(asset($order['image'])); ?>"
                            alt="<?php echo e($order['name']); ?>" class="aspect-[2/1] w-12 object-cover">
                        <h2 class="xl:text-xl font-bold"><?php echo e($order['name']); ?></h2>
                    </div>
                    <p class="text-sm"><?php echo e($order['address']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\lp3\resources\views/livewire/bacancypage/our-office-location.blade.php ENDPATH**/ ?>