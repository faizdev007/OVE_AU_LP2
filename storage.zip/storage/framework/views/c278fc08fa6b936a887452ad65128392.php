<?php if (isset($component)) { $__componentOriginale3373ae1c61e2e4b9384faaad72ac29c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3373ae1c61e2e4b9384faaad72ac29c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.page.bacancy','data' => ['title' => __('Dashboard'),'seo' => $seo??['metaTitle'=>'','metaDescription'=>'']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.page.bacancy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dashboard')),'seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo??['metaTitle'=>'','metaDescription'=>''])]); ?>
    <div class="fixed gap-4 top-0 bottom-0 start-0 end-0 z-40 h-full flex justify-center items-center flex-col text-center p-6 bg-bacancy-primary border rounded">
        <h2 class="md:text-5xl text-3xl text-white font-bold font-mono">Thank You!</h2>
        <p class="text-white mt-2 text-xl">Thanks for your query. Our representative will get in touch with you soon!</p>
        <a class="bg-black p-2 text-white rounded-md" href="<?php echo e(url()->previous()); ?>">Go to Home</a>
    </div>
    <script>
        fetch("<?php echo e(url('/run-queue?key=' . env('QUEUE_SECRET_KEY'))); ?>")
            .then(response => response.text())
            .then(data => console.log("Queue triggered:", data))
            .catch(error => console.error("Queue error:", error));
    </script>
    <?php
        session()->forget('allow_success')
    ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3373ae1c61e2e4b9384faaad72ac29c)): ?>
<?php $attributes = $__attributesOriginale3373ae1c61e2e4b9384faaad72ac29c; ?>
<?php unset($__attributesOriginale3373ae1c61e2e4b9384faaad72ac29c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3373ae1c61e2e4b9384faaad72ac29c)): ?>
<?php $component = $__componentOriginale3373ae1c61e2e4b9384faaad72ac29c; ?>
<?php unset($__componentOriginale3373ae1c61e2e4b9384faaad72ac29c); ?>
<?php endif; ?>
<?php /**PATH /home3/oveau/public_html/resources/views/thankyou.blade.php ENDPATH**/ ?>