
<ui-close data-flux-modal-close>
    <?php echo e($slot); ?>

</ui-close>
<?php /**PATH C:\xampp\htdocs\OVE_Landing_Page_Deployment_Data\AU\CICD_SetUP\vendor\livewire\flux\src/../stubs/resources/views/flux/modal/close.blade.php ENDPATH**/ ?>