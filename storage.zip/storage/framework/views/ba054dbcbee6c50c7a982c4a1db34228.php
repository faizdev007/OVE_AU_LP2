<div>
    <div class="md:flex md:p-0 py-4 items-center justify-between">
        <!-- Left info panel -->
        <div class="flex-1 w-full aspect-[1/1] relative md:block hidden">
            <img loading="eager" fetchpriority="high" decoding="async" src="<?php echo e(asset('assets/modalpic2.webp')); ?>" alt="book_a_30_mins_strategy_call" height="500px" width="500px" class="w-full h-full object-cover" />
            <div class="bg-black/50 h-full w-full absolute top-0 bottom-0 start-0 end-0 z-10"></div>
            <div class="absolute top-0 bottom-0 start-0 end-0 z-20 flex flex-col justify-around h-full gap-2 p-4 text-white">
                <h2 class="md:text-2xl text-xl text-center"><?php echo e($title); ?></h2>
                <ul>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex gap-2 items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-5 text-green-500">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z" clip-rule="evenodd" />
                        </svg>
                        <?php echo e($item); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
                <div class="grid gap-2">
                    <h4><?php echo e($stacktitle); ?></h4>
                    <div class="grid grid-cols-4 gap-2">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $stack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="">
                            <h3 class="font-bold uppercase"><?php echo e($single['title']); ?></h3>
                            <p><?php echo e($single['description']); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="w-full flex justify-start">
                    <img loading="lazy" decoding="async" src="<?php echo e(asset($old_path)); ?>" alt="google rating" class="h-14"/>
                </div>
            </div>
        </div>

        <!-- Right form panel -->
        <div class="flex-1 w-full aspect-[1/1] md:py-0">
            <div class="max-w-3xl mx-auto p-6 space-y-2">
                <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['center' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['center' => true]); ?>
                    <h2 class="text-xl md:text-3xl font-bold  text-black text-center"><?php echo e($formtitle); ?></h2>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
                <h2 class="md:text-xl text-md text-center py-2  text-black"><?php echo e($formsubtitle); ?></h2>
                <hr class="border-black">
                
                <div class="w-full hidden bg-gray-200 rounded-full h-2 mb-6">
                    <div class="h-2 bg-bacancy-primary rounded-full transition-all duration-300"
                         style="width: <?php echo e($step == 1 ? '50%' : '100%'); ?>;">
                    </div>
                </div>

                <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                    <div class="mb-4 rounded-lg bg-green-50 text-green-800 px-4 py-3"><?php echo e(session('message')); ?></div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php if(session()->has('error')): ?>
                    <div class="mb-4 rounded-lg bg-red-50 text-red-800 px-4 py-3"><?php echo e(session('error')); ?></div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
                <!--[if BLOCK]><![endif]--><?php if($step == 1): ?>
                    <form wire:submit.prevent="nextStep" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium mb-1" for="full_name">Full Name</label>
                            <input type="text" id="full_name" wire:model="full_name" 
                                   class="w-full rounded-xl border px-3 py-2 focus:outline-none focus:ring-2 bg-white focus:ring-blue-700 <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-600 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   placeholder="Enter full name">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div>
                            <label class="block text-sm font-medium mb-1" for="company_email">Company Email</label>
                            <input type="email" id="company_email" wire:model="company_email"
                                   class="w-full rounded-xl border px-3 py-2 focus:outline-none focus:ring-2 bg-white focus:ring-blue-700 <?php $__errorArgs = ['company_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-600 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   placeholder="Enter email">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['company_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <small class="text-gray-500">— no Gmail/Yahoo/Hotmail allowed</small>
                        </div>

                        <div>
                            <label class="block text-sm font-medium mb-1" for="phone">Phone</label>
                            <input type="text" id="phone" wire:model="phone"
                                   class="w-full rounded-xl border px-3 py-2 focus:outline-none focus:ring-2 bg-white focus:ring-blue-700 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-600 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   placeholder="Enter phone number">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <?php if (isset($component)) { $__componentOriginal13113c9f32f6116c43cb9fbecee94495 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13113c9f32f6116c43cb9fbecee94495 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.submit-button','data' => ['type' => 'submit','title' => 'Next','target' => 'nextStep','class' => 'w-full !md:text-2xl hover:!bg-gray-900 hover:!text-white focus:!ring-[#000000]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','title' => 'Next','target' => 'nextStep','class' => 'w-full !md:text-2xl hover:!bg-gray-900 hover:!text-white focus:!ring-[#000000]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $attributes = $__attributesOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $component = $__componentOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__componentOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
                    </form>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
                <!--[if BLOCK]><![endif]--><?php if($step == 2): ?>
                    <form wire:submit.prevent="verifyOtp" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium mb-1" for="otp">Enter OTP</label>
                            <input type="text" id="otp" wire:model="otp"
                                   class="w-full rounded-xl border px-3 py-2 focus:outline-none focus:ring-2 bg-white focus:ring-blue-700 <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-600 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   placeholder="<?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php else: ?> Enter the OTP sent to your email <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        </div>

                        <div class="flex justify-between">
                            <!--[if BLOCK]><![endif]--><?php if($otpSent): ?>
                                <button type="button"
                                        <?php if(!$resendCooldown): ?> wire:click="resendOtp" disabled <?php endif; ?>
                                        class="rounded-xl bg-yellow-400 px-4 py-2 text-white hover:bg-yellow-500">
                                    Resend OTP
                                </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="flex justify-between">
                            <?php if (isset($component)) { $__componentOriginal13113c9f32f6116c43cb9fbecee94495 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13113c9f32f6116c43cb9fbecee94495 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.submit-button','data' => ['type' => 'submit','title' => 'Verify OTP','target' => 'nextStep','class' => 'w-full !md:text-2xl hover:!bg-gray-900 hover:!text-white focus:!ring-[#000000]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','title' => 'Verify OTP','target' => 'nextStep','class' => 'w-full !md:text-2xl hover:!bg-gray-900 hover:!text-white focus:!ring-[#000000]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $attributes = $__attributesOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $component = $__componentOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__componentOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
                        </div>
                    </form>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>

    <script>
        (function(){
            setTimeout(() => {
                Livewire.emit('resetResendCooldown');
            }, 60 * 1000);
        })
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\lp4\resources\views/livewire/modal/hire-developer.blade.php ENDPATH**/ ?>