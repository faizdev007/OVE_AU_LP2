<div class="my-12 scroll-mt-20" id="725" section="clients-profile">
    
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
        <div class="py-4">
            <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 border-bacancy-primary">
                <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
                <legend class="text-xl font-bold text-gray-900  markque px-2">Client Success Stories That Go Beyond Testimonials</legend>
                <p class="text-gray-600 dark:text-gray-400">Explore how we helped businesses scale, pivot, and win in competitive markets</p>
                <form wire:submit.prevent="save" class="mt-2 flex-1 overflow-hidden max-w-7xl mx-auto ">
                    <div class="md:flex mb-3">
                        <input wire:model="title" type="text"
                                class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2  border-bacancy-primary rounded-md w-full"
                                placeholder="Title" />
                    </div>
                    <textarea wire:model="subtitle" rows="2" type="text"
                        class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2 border-bacancy-primary rounded-md w-full"
                        placeholder="SubTitle" ></textarea>
    
                    <fieldset class="mb-4 border-2 border-black p-4">
                        <legend class="text-gray-600 dark:text-gray-400 font-bold">Clients Information Area</legend>
                        <div class="grid md:grid-cols-3 sm:grid-cols-2 mb-4 gap-2">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="grid md:grid-cols-3">
                                    <div class="">
                                        <label class="block h-full flex items-center justify-center border shadow font-semibold">
                                            <?php 
                                                if ($client['poster'] && is_object($client['poster'])) {
                                                    $url = $client['poster']->temporaryUrl();
                                                } else {
                                                    $url = asset($client['poster']);
                                                }
                                            ?>
                                            <!--[if BLOCK]><![endif]--><?php if($client['poster']): ?>
                                                <img wire:loading.remove wire:target="clients.<?php echo e($index); ?>.poster" src="<?php echo e($url); ?>" class="rounded border" />
                                            <?php else: ?>
                                                <div wire:loading.remove wire:target="clients.<?php echo e($index); ?>.poster" class="w-full h-full flex items-center text-black justify-center flex-col bg-gray-100 text-center text-xs rounded">
                                                    <p>Poster Image</p>
                                                    <span>(webp, max 2MB)</span>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <span wire:loading class="text-black" wire:target="clients.<?php echo e($index); ?>.poster"> Loading...</span>
                                            <input type="file" wire:model="clients.<?php echo e($index); ?>.poster" wire:change="changeClient(<?php echo e($index); ?>)" accept=".webp,.jpg,.jpeg,.png" class="w-full hidden mb-1 border p-2 rounded" />
                                        </label>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["clients.$index.poster"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->  
                                    </div>
                                    <div class="border p-4 col-span-2 rounded flex flex-col text-black justify-between shadow relative">
                                        <div class="text-right">
                                            <!--[if BLOCK]><![endif]--><?php if(count($clients) > 1): ?>
                                                <button type="button" wire:click="removeClient(<?php echo e($index); ?>)" class="absolute top-0 end-0 bg-red-500 text-white h-8 w-8 rounded-b-none rounded-s-none rounded hover:bg-red-600">X</button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
        
                                        <div>
                                            <label class="hidden font-semibold">Name</label>
                                            <input type="text" wire:model.lazy="clients.<?php echo e($index); ?>.name" placeholder="Name" class="w-full mb-2 mt-5 border p-2 rounded" />
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["clients.$index.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
        
                                        <div>
                                            <label class="hidden font-semibold">Title</label>
                                            <input type="text" wire:model.lazy="clients.<?php echo e($index); ?>.title" placeholder="Title" class="w-full mb-2 border p-2 rounded" />
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["clients.$index.title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
        
                                        <div>
                                            <label class="hidden font-semibold">Video URL</label>
                                            <input type="text" wire:model.lazy="clients.<?php echo e($index); ?>.video" placeholder="Video URL" class="w-full mb-2 border p-2 rounded" />
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["clients.$index.video"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
        
                                        <div class="hidden">
                                            <label class="block font-semibold">Poster Image</label>
                                            <input type="file" wire:model="clients.<?php echo e($index); ?>.poster" accept=".webp,.jpg,.jpeg,.png" class="w-full mb-2 border p-2 rounded" />
                                            <span>only (webp, max 2MB)</span>
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["clients.$index.poster"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->  
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <button type="button" wire:click="addClient" class="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700">
                            + Add More Client
                        </button>
                    </fieldset>
                    <!-- Save Button -->
                    <div class="absolute -top-10 px-2 end-0 flex justify-center">
                        <button type="submit" wire:loading.attr="disabled" class="px-6 cursor-pointer py-3 bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                            <span wire:loading wire:target="save">saving...</span>
                            <span wire:loading.remove wire:target="save">Save</span>
                        </button>
                    </div>
                </form>
            </fieldset>
        </div>
    <?php else: ?>
    <div class="relative grid gap-4 px-4 py-2 sm:px-6 lg:px-8 mx-auto ">
        <div class="w-full mx-auto 2xl:text-2xl">
            <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <h2 class="text-2xl xl:text-[45px] text-black font-extrabold"><?php echo e($title); ?></h2>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::subheading','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::subheading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <p class="mt-2 text-black xl:text-xl md:text-sm mb-6"><?php echo e($subtitle); ?></p>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $attributes = $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $component = $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
        </div>
        <?php if (isset($component)) { $__componentOriginala928ab1928fd2c4683b3d21429b7a446 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala928ab1928fd2c4683b3d21429b7a446 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bacancypage.client-card','data' => ['clients' => $clients]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bacancypage.client-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['clients' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($clients)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala928ab1928fd2c4683b3d21429b7a446)): ?>
<?php $attributes = $__attributesOriginala928ab1928fd2c4683b3d21429b7a446; ?>
<?php unset($__attributesOriginala928ab1928fd2c4683b3d21429b7a446); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala928ab1928fd2c4683b3d21429b7a446)): ?>
<?php $component = $__componentOriginala928ab1928fd2c4683b3d21429b7a446; ?>
<?php unset($__componentOriginala928ab1928fd2c4683b3d21429b7a446); ?>
<?php endif; ?>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /home3/oveau/public_html/resources/views/livewire/bacancypage/clients-profile.blade.php ENDPATH**/ ?>