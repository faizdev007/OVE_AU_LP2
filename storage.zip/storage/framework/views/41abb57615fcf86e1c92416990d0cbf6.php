<div class="my-12" section="projects">
    
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
        <div class="py-4">
            <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 border-bacancy-primary">
                <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
                <legend class="text-xl font-bold text-gray-900  markque px-2">Project display section</legend>
                <p class="text-gray-600 dark:text-gray-400">You can add and remove Project which you want to display!</p>
                    <div>
                        <form wire:submit.prevent="save" class="mt-2 p-1 flex-1 overflow-hidden max-w-7xl mx-auto ">
                        <div class="md:flex mb-3">
                            <input wire:model="title" type="text"
                                    class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2  border-bacancy-primary rounded-md w-full"
                                    placeholder="Title" />
                        </div>
                        <textarea wire:model="subtitle" rows="2" type="text"
                            class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2 border-bacancy-primary rounded-md w-full"
                            placeholder="SubTitle" ></textarea>
        
                        <fieldset class="mb-4 border-2 border-black p-4">
                            <legend class="text-gray-600 dark:text-gray-400 font-bold">Project Information Area</legend>
                            <div class="grid md:grid-cols-2 gap-4">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <div class="block">
                                            
                                            <div>
                                                <label class="block aspect-[2/1] object-container flex justify-center items-center h-full border shadow font-semibold">

                                                    <?php
                                                        $image = $project['web_pic'] ?? null;
                                                        $isTempUpload = is_object($image);
                                                    ?>

                                                    
                                                    <!--[if BLOCK]><![endif]--><?php if($isTempUpload): ?>
                                                        <img loading="lazy" src="<?php echo e($image->temporaryUrl()); ?>" class="rounded border w-full aspect-[2/1] object-container" />
                                                    <?php elseif($image): ?>
                                                        <img wire:loading.remove wire:target="projects.<?php echo e($index); ?>.web_pic" loading="lazy" src="<?php echo e(asset($image)); ?>" class="rounded border w-full aspect-[2/1] object-container" />
                                                    <?php else: ?>
                                                        <div wire:loading.remove wire:target="projects.<?php echo e($index); ?>.web_pic" class="w-full h-full aspect-[2/1] flex items-center justify-center flex-col bg-gray-100 text-center text-xs rounded text-black">
                                                            <p>Project Image</p>
                                                            <span>(webp, max 300kb)</span>
                                                        </div>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                                    <div wire:loading wire:target="projects.<?php echo e($index); ?>.web_pic" class="text-black">
                                                        Loading...
                                                    </div>

                                                    <!-- File Input -->
                                                    <input 
                                                        type="file" 
                                                        wire:model="projects.<?php echo e($index); ?>.web_pic"
                                                        wire:change="removeChangeImg(<?php echo e($index); ?>)"
                                                        accept=".webp"
                                                        class="w-full hidden"
                                                    />
                                                </label>
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["projects.$index.web_pic"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                    <span class="text-red-500"><?php echo e($message); ?></span> 
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->  
                                            </div>

                                            
                                            <div class="border p-4 col-span-2 rounded flex flex-col text-black justify-between shadow relative">
                                                
                                                <div class="text-right">
                                                    <!--[if BLOCK]><![endif]--><?php if(count($projects) > 1): ?>
                                                        <button type="button" wire:click="removeProject(<?php echo e($index); ?>)" class="absolute top-0 end-0 bg-red-500 text-white h-8 w-8 rounded hover:bg-red-600">X</button>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>

                                                <div class="mt-5">
                                                    <input type="text" wire:model.lazy="projects.<?php echo e($index); ?>.project_name" placeholder="Project Name" class="w-full mb-2 border p-2 rounded" />
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["projects.$index.project_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                                    <input type="text" wire:model.lazy="projects.<?php echo e($index); ?>.label_tag" placeholder="Label Tag" class="w-full mb-2 border p-2 rounded" />
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["projects.$index.label_tag"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                                    <textarea wire:model.lazy="projects.<?php echo e($index); ?>.brief_detail" rows="2" placeholder="Brief Detail" class="w-full mb-2 border p-2 rounded"></textarea>
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["projects.$index.brief_detail"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>

                                                
                                                <div class="mt-2">
                                                    <label class="block font-semibold">Highlights</label>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $project['highlights']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlightIndex => $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="flex gap-2 items-center mb-2">
                                                            <input type="text" wire:model.lazy="projects.<?php echo e($index); ?>.highlights.<?php echo e($highlightIndex); ?>" class="w-full border p-2 rounded" placeholder="Highlight <?php echo e($highlightIndex + 1); ?>" />
                                                            <button type="button" wire:click="removeHighlight(<?php echo e($index); ?>, <?php echo e($highlightIndex); ?>)" class="text-red-500 font-bold">✕</button>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                    <button type="button" wire:click="addHighlight(<?php echo e($index); ?>)" class="mt-1 text-sm bg-gray-300 px-2 py-1 rounded hover:bg-gray-400">+ Add Highlight</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            
                            <button type="button" wire:click="addProject" class="mt-4 bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700">
                                + Add More Project
                            </button>
                        </fieldset>
                        <!-- Save Button -->
                        <div class="absolute -top-10 px-2 end-0 flex justify-center">
                            <button type="submit" wire:loading.attr="disabled" class="px-6 cursor-pointer py-3 bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                                <span wire:loading wire:target="save">saving...</span>
                                <span wire:loading.remove wire:target="save">Save</span>
                            </button>
                        </div>
                    </form>
                </div>
            </fieldset>
        </div>
    <?php else: ?>
    <div class="relative grid text-center gap-4 px-4 py-2 sm:px-6 lg:px-8 overflow-hidden mx-auto ">
        <div class="w-full mx-auto">
            <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <h2 class="text-2xl xl:text-[45px] text-black font-extrabold"><?php echo e($title); ?></h2>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::subheading','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::subheading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                <p class="mt-2 text-black xl:text-xl md:text-sm mb-6"><?php echo e($subtitle); ?></p>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $attributes = $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $component = $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
        </div>
        <?php if (isset($component)) { $__componentOriginal687c686bb5a85506176f4c42fb855745 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal687c686bb5a85506176f4c42fb855745 = $attributes; } ?>
<?php $component = App\View\Components\AutoSlider::resolve(['cardmd' => 1,'cardlg' => 1,'cardxl' => 1,'card2xl' => 1,'interval' => 6000] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auto-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AutoSlider::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal6cfb60422bb348ba2438a2781141bf76 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cfb60422bb348ba2438a2781141bf76 = $attributes; } ?>
<?php $component = App\View\Components\Bacancypage\ProjectCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bacancypage.project-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Bacancypage\ProjectCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['project' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($project)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cfb60422bb348ba2438a2781141bf76)): ?>
<?php $attributes = $__attributesOriginal6cfb60422bb348ba2438a2781141bf76; ?>
<?php unset($__attributesOriginal6cfb60422bb348ba2438a2781141bf76); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cfb60422bb348ba2438a2781141bf76)): ?>
<?php $component = $__componentOriginal6cfb60422bb348ba2438a2781141bf76; ?>
<?php unset($__componentOriginal6cfb60422bb348ba2438a2781141bf76); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal687c686bb5a85506176f4c42fb855745)): ?>
<?php $attributes = $__attributesOriginal687c686bb5a85506176f4c42fb855745; ?>
<?php unset($__attributesOriginal687c686bb5a85506176f4c42fb855745); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal687c686bb5a85506176f4c42fb855745)): ?>
<?php $component = $__componentOriginal687c686bb5a85506176f4c42fb855745; ?>
<?php unset($__componentOriginal687c686bb5a85506176f4c42fb855745); ?>
<?php endif; ?>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\OVE_Landing_Page_Deployment_Data\AU\CICD_SetUP\resources\views/livewire/bacancypage/projects.blade.php ENDPATH**/ ?>