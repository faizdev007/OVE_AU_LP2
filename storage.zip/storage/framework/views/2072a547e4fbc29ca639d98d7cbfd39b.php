<?php if (isset($component)) { $__componentOriginale3373ae1c61e2e4b9384faaad72ac29c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3373ae1c61e2e4b9384faaad72ac29c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.page.bacancy','data' => ['header' => $header,'seo' => $seo??['metaTitle'=>'','metaDescription'=>''],'title' => __('Optimal Virtual Employee')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.page.bacancy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($header),'seo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($seo??['metaTitle'=>'','metaDescription'=>'']),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Optimal Virtual Employee'))]); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('s-e-o', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.header', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.herosection', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.profiles', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.companies-logo', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.under-one-roof', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.tech-stack', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.ai-block', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.clients-profile', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.projects', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-9', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.faq', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-10', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bacancypage.our-office-location', ['lpData' => $lp_data ?? [],'lp_data' => $lp_data ?? []]);

$__html = app('livewire')->mount($__name, $__params, 'lw-770860088-11', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3373ae1c61e2e4b9384faaad72ac29c)): ?>
<?php $attributes = $__attributesOriginale3373ae1c61e2e4b9384faaad72ac29c; ?>
<?php unset($__attributesOriginale3373ae1c61e2e4b9384faaad72ac29c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3373ae1c61e2e4b9384faaad72ac29c)): ?>
<?php $component = $__componentOriginale3373ae1c61e2e4b9384faaad72ac29c; ?>
<?php unset($__componentOriginale3373ae1c61e2e4b9384faaad72ac29c); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lp3\resources\views/landing_pages/bacancy.blade.php ENDPATH**/ ?>