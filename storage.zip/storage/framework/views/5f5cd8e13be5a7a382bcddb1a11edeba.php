
<div class="my-12 scroll-mt-20" id="723" section="developer-profile">
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
        <div class="py-4">
            <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 border-bacancy-primary">
                <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
                <legend class="text-xl font-bold text-gray-900  markque px-2">Developer Profile Section</legend>
                <p class="text-gray-600 ">Customize the Developer Profile section of your Bacancy landing page.</p>
                <form wire:submit.prevent="save" class="mt-2 flex-1 overflow-hidden max-w-7xl text-black mx-auto ">
                    <div class="md:flex mb-3">
                        <input wire:model="developer_title" type="text"
                                class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border md:p-4 p-2  border-bacancy-primary rounded-md w-full"
                                placeholder="Title" />
                    </div>
                    <textarea wire:model="developer_subtitle" rows="4" type="text"
                        class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border xl:p-6 md:p-4 p-2 border-bacancy-primary rounded-md w-full"
                        placeholder="SubTitle" ></textarea>   

                    <fieldset class="mb-6 border-2 border-black p-4">
                        <legend class="text-gray-600 font-bold">Developer Profiles</legend>

                        <div class="grid md:grid-cols-3 gap-4">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $developer_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-6 border p-4 rounded border-black relative shadow-sm bg-gray-50">

                                    
                                    <div class="mt-4 text-right absolute -top-4 end-0">
                                        <!--[if BLOCK]><![endif]--><?php if(count($developer_list) > 1): ?>
                                            <button type="button" wire:click="removeDeveloper(<?php echo e($index); ?>)"
                                                class="px-3 py-1 bg-red-500 text-white rounded-tr hover:bg-red-600">
                                                X
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    
                                    <div class="flex items-center gap-4 mb-4">
                                        <label class="cursor-pointer">
                                            <!--[if BLOCK]><![endif]--><?php if(isset($dev['avtar']) && is_object($dev['avtar'])): ?>
                                                <img src="<?php echo e($dev['avtar']->temporaryUrl()); ?>" class="h-24 w-24 object-cover rounded-full border shadow-md" alt="Avatar Preview" />
                                            <?php elseif($dev['avtar']  && !is_object($dev['avtar'])): ?>
                                                <img src="<?php echo e(asset($dev['avtar'])); ?>" class="h-24 w-24 object-cover rounded-full border shadow-md" alt="Stored Avatar" />
                                            <?php else: ?>
                                                <div class="h-24 w-24 flex items-center justify-center rounded-full bg-gray-200 border shadow-md text-sm text-gray-500">
                                                    Upload
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <input type="file" wire:model="developer_list.<?php echo e($index); ?>.avtar" wire:change="removeAvtar(<?php echo e($index); ?>)" accept=".webp" class="hidden" />
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["developer_list.$index.avtar"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </label>

                                        <div class="flex-1">
                                            <input type="text" wire:model.defer="developer_list.<?php echo e($index); ?>.name" maxlength="20"
                                                class="p-2 w-full border border-black rounded-md shadow-sm"
                                                placeholder="Developer Name" />
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["developer_list.$index.name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>

                                    
                                    <div class="flex gap-2 mb-4">
                                        <input type="text" wire:model.defer="developer_list.<?php echo e($index); ?>.profile" maxlength="20"
                                            class="p-2 w-full rounded-md border border-black shadow-sm"
                                            placeholder="Developer Profile" />
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["developer_list.$index.profile"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                        <label class="cursor-pointer relative w-full rounded bg-gray-700">
                                            <!--[if BLOCK]><![endif]--><?php if(isset($dev['company_logo']) && is_object($dev['company_logo'])): ?>
                                                <img src="<?php echo e($dev['company_logo']->temporaryUrl()); ?>" class="h-12 w-full object-cover rounded border shadow-md" />
                                            <?php elseif($dev['company_logo'] && !is_object($dev['company_logo'])): ?>
                                                <img src="<?php echo e(asset($dev['company_logo'])); ?>" class="h-12 w-full object-cover rounded border shadow-md" />
                                            <?php else: ?>
                                                <div class="h-12 w-full flex items-center justify-center border shadow-md text-sm text-white p-2">
                                                    Upload Logo
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                            <input type="file" wire:model="developer_list.<?php echo e($index); ?>.company_logo" wire:change="removeLogo(<?php echo e($index); ?>)" accept=".webp" class="hidden" />
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["developer_list.$index.company_logo"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </label>
                                    </div>

                                    
                                    <div class="mb-3">
                                        <input type="text" wire:model.defer="developer_list.<?php echo e($index); ?>.tools" maxlength="50"
                                            class="p-2 w-full rounded-md border border-black shadow-sm"
                                            placeholder="Tech Tools" />
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["developer_list.$index.tools"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    
                                    <div>
                                        <textarea wire:model.defer="developer_list.<?php echo e($index); ?>.info" maxlength="300" rows="3"
                                            class="p-2 w-full rounded-md border border-black shadow-sm"
                                            placeholder="Short Description (Max 300 characters)"></textarea>
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["developer_list.$index.info"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        
                        <div class="text-left mt-4">
                            <button type="button" wire:click="addDeveloper"
                                class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">
                                + Add Developer
                            </button>
                        </div>
                    </fieldset>



                    <!-- Save Button -->
                    <div class="absolute -top-10 px-2 end-0 flex justify-center">
                        <button type="submit" wire:loading.attr="disabled" class="px-6 cursor-pointer py-3 bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                            <span wire:loading wire:target="save">saving...</span>
                            <span wire:loading.remove wire:target="save">Save</span>
                        </button>
                    </div>
                </form>
            </fieldset>
        </div>
    <?php else: ?>
        <div class="relative grid text-center gap-4 px-4 py-2 sm:px-6 lg:px-8 overflow-hidden mx-auto">
            <div class="w-full max-w-5xl mx-auto">
                <?php if (isset($component)) { $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::heading','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                    <h2 class="text-2xl xl:text-[45px] font-extrabold text-gray-900 "><?php echo e($developer_title); ?></h2>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $attributes = $__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__attributesOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9)): ?>
<?php $component = $__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9; ?>
<?php unset($__componentOriginale0fd5b6a0986beffac17a0a103dfd7b9); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::subheading','data' => ['class' => 'text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::subheading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center']); ?>
                    <p class="mt-2 text-black xl:text-xl md:text-sm "><?php echo e($developer_subtitle); ?></p>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $attributes = $__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__attributesOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97)): ?>
<?php $component = $__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97; ?>
<?php unset($__componentOriginal43e8c568bbb8b06b9124aad3ccf4ec97); ?>
<?php endif; ?>
            </div>
            <?php
                $profiles = $developer_list;
            ?>
            <!-- Carousel -->
            <?php if (isset($component)) { $__componentOriginal687c686bb5a85506176f4c42fb855745 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal687c686bb5a85506176f4c42fb855745 = $attributes; } ?>
<?php $component = App\View\Components\AutoSlider::resolve(['cardmd' => 2,'cardlg' => 4,'cardxl' => 4,'card2xl' => 5,'autoSlide' => true,'interval' => 8000] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auto-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AutoSlider::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal9ec263a7872b0a6478292e0398b3811c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ec263a7872b0a6478292e0398b3811c = $attributes; } ?>
<?php $component = App\View\Components\Bacancypage\ProfileCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bacancypage.profile-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Bacancypage\ProfileCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['profile' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profile)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ec263a7872b0a6478292e0398b3811c)): ?>
<?php $attributes = $__attributesOriginal9ec263a7872b0a6478292e0398b3811c; ?>
<?php unset($__attributesOriginal9ec263a7872b0a6478292e0398b3811c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ec263a7872b0a6478292e0398b3811c)): ?>
<?php $component = $__componentOriginal9ec263a7872b0a6478292e0398b3811c; ?>
<?php unset($__componentOriginal9ec263a7872b0a6478292e0398b3811c); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal687c686bb5a85506176f4c42fb855745)): ?>
<?php $attributes = $__attributesOriginal687c686bb5a85506176f4c42fb855745; ?>
<?php unset($__attributesOriginal687c686bb5a85506176f4c42fb855745); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal687c686bb5a85506176f4c42fb855745)): ?>
<?php $component = $__componentOriginal687c686bb5a85506176f4c42fb855745; ?>
<?php unset($__componentOriginal687c686bb5a85506176f4c42fb855745); ?>
<?php endif; ?>
            <!-- Carousel Controls -->
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\lp3\resources\views/livewire/bacancypage/profiles.blade.php ENDPATH**/ ?>