<center>
    <h2>Your OTP Code</h2>
    <h1><strong><?php echo e($otp); ?></strong></h1>
</center><?php /**PATH C:\xampp\htdocs\lp4\resources\views/emails/otp.blade.php ENDPATH**/ ?>