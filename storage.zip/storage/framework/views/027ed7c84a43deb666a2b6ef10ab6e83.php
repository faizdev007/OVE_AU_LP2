<div>
    <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['devProfile']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['devProfile']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
    <div class="relative flex md:flex-row flex-col items-center justify-center gap-4 md:space-y-0 space-y-48 md:py-10 px-4 py-2 sm:px-6 lg:px-8 overflow-hidden mx-auto h-full">
        <div class="lg:w-none m-4 md:w-[40%] pb-12 flex md:items-center flex-col gap-6">
            <div class="aspect-[1/1] h-full absolute">
                <img loading="lazy" decoding="async" src="<?php echo e(asset('assets/siliconvalley/globe-bg.webp')); ?>" width="628" height="628" class="z-0 animate-[spin_4s_linear_infinite] opacity-30 h-full" alt="Silicon Valley Logo"/>
            </div>
            <div class="relative rounded-full lg:w-max">
                <div class="absolute -top-3 bottom-4 z-0 -end-3 start-4  border-2 border-white rounded-full"></div>
                <div class="absolute inset-0 top-4 -bottom-3 z-0 end-4 -start-3  border-2 border-white rounded-full"></div>
                <!-- <div class="absolute inset-0 bg-sv-secondary rounded-full"></div> -->
                <div class="aspect-square xl:w-[400px] xl:h-[400px] md:w-[300px] md:h-[300px] rounded-full overflow-hidden relative z-10">
                    <img loading="lazy" decoding="async" src="<?php echo e(asset($devProfile['image'])); ?>" alt="<?php echo e($devProfile['name']); ?>" width="400" height="400" class="object-cover w-full h-full"/>
                </div>
            </div>
            <div class="z-20 relative flex justify-center">
                <?php if (isset($component)) { $__componentOriginal1db8c57e729d67f7d4103875cf3230cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.trigger','data' => ['name' => 'book-a-call']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal.trigger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book-a-call']); ?>
                    <?php if (isset($component)) { $__componentOriginal223d1ffece829ef6a495ad9046836fbc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal223d1ffece829ef6a495ad9046836fbc = $attributes; } ?>
<?php $component = App\View\Components\SiliconValley\ActionButton::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('silicon-valley.action-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SiliconValley\ActionButton::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hover:bg-sv-secondary/50 text-sm md:text-lg 2xl:text-3xl','x-data' => '','x-on:click.prevent' => '$dispatch(\'open-modal\', \'Hire Now\')','title' => 'lets talk to '.e($devProfile['name']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal223d1ffece829ef6a495ad9046836fbc)): ?>
<?php $attributes = $__attributesOriginal223d1ffece829ef6a495ad9046836fbc; ?>
<?php unset($__attributesOriginal223d1ffece829ef6a495ad9046836fbc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal223d1ffece829ef6a495ad9046836fbc)): ?>
<?php $component = $__componentOriginal223d1ffece829ef6a495ad9046836fbc; ?>
<?php unset($__componentOriginal223d1ffece829ef6a495ad9046836fbc); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $attributes = $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $component = $__componentOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="text-white md:w-[60%] w-full flex gap-6 flex-col space-y-4 relative">
            <span class="text-lg md:text-start text-center">Say Hello To</span>
            <div class="flex md:flex-row flex-col gap-6 items-center justify-between">
                <h2 class="2xl:text-6xl text-3xl font-bold"><?php echo e($devProfile['name']); ?></h2>
                <div x-data="{ rating: <?php echo e($devProfile['starts']); ?> }" class="flex items-center text-md 2xl:w-none space-x-1">
                    <template x-for="star in 5" :key="star">
                        <div class="relative 2xl:w-8 2xl:h-8 md:w-4 md:h-4 w-3 h-3">
                            <!-- Empty star -->
                            <svg 
                                class="absolute inset-0 w-full h-full text-gray-300" 
                                fill="currentColor" 
                                viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.146 3.53a1 1 0 00.95.69h3.708c.969 0 1.371 1.24.588 1.81l-3 2.18a1 1 0 00-.364 1.118l1.146 3.53c.3.921-.755 1.688-1.54 1.118l-3-2.18a1 1 0 00-1.176 0l-3 2.18c-.785.57-1.84-.197-1.54-1.118l1.146-3.53a1 1 0 00-.364-1.118l-3-2.18c-.783-.57-.38-1.81.588-1.81h3.708a1 1 0 00.95-.69l1.146-3.53z" />
                            </svg>

                            <!-- Full star -->
                            <svg 
                                x-show="rating >= star" 
                                class="absolute inset-0 w-full h-full text-yellow-400" 
                                fill="currentColor" 
                                viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.146 3.53a1 1 0 00.95.69h3.708c.969 0 1.371 1.24.588 1.81l-3 2.18a1 1 0 00-.364 1.118l1.146 3.53c.3.921-.755 1.688-1.54 1.118l-3-2.18a1 1 0 00-1.176 0l-3 2.18c-.785.57-1.84-.197-1.54-1.118l1.146-3.53a1 1 0 00-.364-1.118l-3-2.18c-.783-.57-.38-1.81.588-1.81h3.708a1 1 0 00.95-.69l1.146-3.53z" />
                            </svg>

                            <!-- Half star -->
                            <svg 
                                x-show="rating > star - 1 && rating < star" 
                                class="absolute inset-0 w-full h-full text-yellow-400" 
                                fill="currentColor" 
                                viewBox="0 0 20 20">
                                <defs>
                                    <linearGradient id="half">
                                        <stop offset="50%" stop-color="currentColor" />
                                        <stop offset="50%" stop-color="transparent" stop-opacity="1" />
                                    </linearGradient>
                                </defs>
                                <path 
                                    fill="url(#half)" 
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.146 3.53a1 1 0 00.95.69h3.708c.969 0 1.371 1.24.588 1.81l-3 2.18a1 1 0 00-.364 1.118l1.146 3.53c.3.921-.755 1.688-1.54 1.118l-3-2.18a1 1 0 00-1.176 0l-3 2.18c-.785.57-1.84-.197-1.54-1.118l1.146-3.53a1 1 0 00-.364-1.118l-3-2.18c-.783-.57-.38-1.81.588-1.81h3.708a1 1 0 00.95-.69l1.146-3.53z" />
                            </svg>
                        </div>
                    </template>

                    <span class="ml-3 lg:text-sm text-xs" x-text="rating + ' / 5'"></span>
                </div>
            </div>
            <p class=""><?php echo e($devProfile['description']); ?></p>
            <!--[if BLOCK]><![endif]--><?php if(isset($devProfile['techStack'])): ?>
                <span><code><</code>Tech I work on <code>/ ></code></span>
                <div class="flex gap-2 flex-wrap">
                    <?php
                        $techstacks = explode(',',$devProfile['techStack']);
                    ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $techstacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-col items-center">
                            <span class="text-sm p-1 rounded-full px-4 border shadow drop-shadow bg-black font-bold"><?php echo e(trim($item) ?? ''); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if(count($devProfile['projects']) > 0): ?>
                <span class="hidden"><code><</code>What I Achived <code>/ ></code></span>
                <div class="flex gap-4 hidden">
                    <?php
                        $whatWeDid = $devProfile['projects'] ?? [];
                    ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $whatWeDid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-col aspect-[1.9/2] items-center">
                            <img class="w-full bg-sv-secondary h-full object-cover rounded" src="<?php echo e(asset($item['image'] ?? '')); ?>" alt="<?php echo e($item['title'] ?? ''); ?>">
                            <span class="hidden text-sm mt-2"><?php echo e($item['title'] ?? ''); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\OVE_Landing_Page_Deployment_Data\AU\CICD_SetUP\resources\views/components/silicon-valley/dev-profile.blade.php ENDPATH**/ ?>