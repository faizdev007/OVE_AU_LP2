<div>
    <!-- The only way to do great work is to love what you do. - Steve Jobs -->
     <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title'=> null,
    'alt'=> null,
    'arialabel'=> null,
    ]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title'=> null,
    'alt'=> null,
    'arialabel'=> null,
    ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
    <!-- Because you are alive, everything is possible. - Thich Nhat Hanh -->
    <button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'bg-sv-secondary p-2 px-6 shadow-md hover:bg-sv-primary cursor-pointer font-bold rounded-full  text-white'])); ?>>
        <?php echo e($title); ?>

    </button>
</div><?php /**PATH C:\xampp\htdocs\lp4\resources\views/components/silicon-valley/action-button.blade.php ENDPATH**/ ?>