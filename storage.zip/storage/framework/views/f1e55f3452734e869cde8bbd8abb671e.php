<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['successMessage' => '','errorMessage'=>'']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['successMessage' => '','errorMessage'=>'']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!--[if BLOCK]><![endif]--><?php if($successMessage): ?>
    <div 
        x-data="{ show: true }" 
        x-init="setTimeout(() => {show = false; $wire.set('successMessage','');}, 3000)" 
        x-show="show"
        class="bg-green-100 text-green-800 px-3 py-2 rounded mb-3"
    >
        <?php echo e($successMessage); ?>

    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

<!--[if BLOCK]><![endif]--><?php if($errorMessage): ?>
    <div 
        x-data="{ show: true }" 
        x-init="setTimeout(() => {show = false; $wire.set('errorMessage','');}, 3000)" 
        x-show="show"
        class="bg-red-100 text-red-800 px-3 py-2 rounded mb-3"
    >
        <?php echo e($errorMessage); ?>

    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]--><?php /**PATH C:\xampp\htdocs\OVE_Landing_Page_Deployment_Data\AU\CICD_SetUP\resources\views/components/messagestatus.blade.php ENDPATH**/ ?>